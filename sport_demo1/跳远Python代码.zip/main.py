from RulerSeeker import RulerSeeker
from Jumping import Jumping
from UI import loadMain

import sys
from PyQt5.QtWidgets import QApplication,QWidget



##环境：相机和尺子保持不动。


def show_ruler():
    test_images = 'img/2findRuler.jpg'
    ruler_template = 'img/ruler_template.jpg'
    ruler_seeker = RulerSeeker(test_images, ruler_template)
    ruler_seeker.showInfo()


if __name__ == '__main__':
    # show_ruler()


    app = QApplication(sys.argv)
    loadWin = loadMain()
    loadWin.show()
    sys.exit(app.exec_())
